import 'package:flutter/material.dart';

import 'src/fields/phone_textfield.dart';

class PhonenumberTf extends StatefulWidget {
  const PhonenumberTf({super.key});

  @override
  State<PhonenumberTf> createState() => _PhonenumberTfState();
}

class _PhonenumberTfState extends State<PhonenumberTf> {
  final _phoneController_dropdown = TextEditingController();
  final _phoneController_fixedCode = TextEditingController();
  final _phoneController_icon = TextEditingController();
  final _phoneController_normal = TextEditingController();
  // ignore: non_constant_identifier_names
  final phone_drop_focus = FocusNode();
  final phonefixedfocus = FocusNode();
  final phoneIconFocus = FocusNode();
  final phoneNormalFocus = FocusNode();
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Dropdown Style Phone Input',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          FlexiblePhoneField(
            regexPattern: '',
            controller: _phoneController_dropdown,
            onSubmitted: () {
              print(
                'Flexible Phone Number in Drop down Country code: ${_phoneController_dropdown.text}',
              );
            },
            focusNode: phone_drop_focus,
            hintText: "Enter your mobile number",
            countryCode: "+91",
            style: PhoneFieldStyle.dropdown,
          ),

          const SizedBox(height: 15),

          const Text(
            'Fixed Country Code Style ',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          FlexiblePhoneField(
            controller: _phoneController_fixedCode,
            onSubmitted: () {
              print(
                'Flexible Phone Number in Fixed Country code: ${_phoneController_fixedCode.text}',
              );
            },
            focusNode: phonefixedfocus,
            hintText: "Enter your mobile number",
            countryCode: "+91",
            style: PhoneFieldStyle.integrated,
          ),

          // FlexiblePhoneField(
          //   controller: _phoneController_fixedCode,
          //   initialCountryCode: '+91',
          //   hint: 'Enter your mobile number',
          //   displayMode: PhoneFieldDisplayMode.fixed,
          //   separator: "",
          //   maxLength: 10,
          //   onPhoneChanged: (fullPhoneNumber, phoneNumber, countryCode) {
          //     setState(() {
          //       print(
          //         'Flexible Phone Number in Fixed Country code: $fullPhoneNumber, $phoneNumber, $countryCode',
          //       );
          //     });
          //   },
          // ),
          const SizedBox(height: 15),

          const Text(
            'Phone number with Icons',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          FlexiblePhoneField(
            controller: _phoneController_icon,
            onSubmitted: () {
              print(
                'Flexible Phone Number in ICON Country code: ${_phoneController_icon.text}',
              );
            },
            focusNode: phoneIconFocus,
            hintText: "Enter your mobile number",
            countryCode: "+91",
            style: PhoneFieldStyle.withIcons,
          ),

          const Text(
            'Phone number with Normal',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          FlexiblePhoneField(
            controller: _phoneController_normal,
            onSubmitted: () {
              setState(() {
                print(
                  'Flexible Phone Number in Normal Country code: ${_phoneController_normal.text}',
                );
              });
            },
            focusNode: phoneNormalFocus,
            hintText: "Enter your mobile number",
            countryCode: "+91",
            style: PhoneFieldStyle.simple,
          ),
          // FlexiblePhoneField(
          //   regexPattern: r'^[6-9]\d{9}$',
          //   controller: _phoneController_icon,
          //   hint: 'Enter your phone number',
          //   label: 'Mobile Number',
          //   maxLength: 10,
          //   displayMode: PhoneFieldDisplayMode.phoneOnly,
          //   separator: "",
          //   decoration: InputDecoration(
          //     labelText: 'Mobile Number',
          //     hintText: 'Mobile number (10 digits)',
          //     prefixIcon: const Icon(Icons.smartphone),
          //     border: OutlineInputBorder(
          //       borderRadius: BorderRadius.circular(12),
          //     ),
          //     filled: true,
          //     fillColor: Colors.grey.shade100,
          //   ),
          //   onPhoneChanged: (fullPhoneNumber, phoneNumber, countryCode) {
          //     setState(() {
          //       print(
          //         'Flexible Phone Number only: $fullPhoneNumber, $phoneNumber, $countryCode',
          //       );
          //     });
          //   },
          // ),
        ],
      ),
    );
  }
}
