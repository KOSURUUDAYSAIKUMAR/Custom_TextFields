import 'package:flutter/material.dart';
import 'package:flutter_custom_tfs/otp_field_demo.dart';
import 'src/fields/email_textfield.dart';
import 'src/fields/full_name_textfield.dart';
import 'src/fields/username_textfield.dart';
import 'src/fields/phone_textfield.dart';

class FormExample extends StatefulWidget {
  const FormExample({super.key});

  @override
  State<FormExample> createState() => _FormExampleState();
}

class _FormExampleState extends State<FormExample> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _fullnameController = TextEditingController();
  final _usernameController = TextEditingController();
  final _phoneController = TextEditingController();

  final FocusNode _emailNode = FocusNode();
  final FocusNode _fullnameNode = FocusNode();
  final FocusNode _usernameNode = FocusNode();
  final FocusNode _phoneNode = FocusNode();

  @override
  void dispose() {
    _emailController.dispose();
    _usernameController.dispose();
    _fullnameController.dispose();
    _phoneController.dispose();
    _emailNode.dispose();
    _fullnameNode.dispose();
    _usernameNode.dispose();
    _phoneNode.dispose();
    super.dispose();
  }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Form submitted successfully')),
      );
      print('Email: ${_emailController.text}');
      print('Username: ${_usernameController.text}');
      print('Full Name: ${_fullnameController.text}');
      print('Phone: ${_phoneController.text}');
    } else {
      // Show error message when form is invalid on submit
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please fix the errors in the form'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Flutter Custom Fields Demo')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Email Field
              const Text(
                'Email Field with Validation',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              EmailTextField(
                controller: _emailController,
                focusNode: _emailNode,
                iconColor: Theme.of(context).primaryColor,
                autovalidateMode: AutovalidateMode.onUserInteraction,
                invalidEmailMessage: 'Please enter a valid email address',
                requiredEmailMessage: 'Email is required',
              ),
              const SizedBox(height: 16),

              const Text(
                'Full Name with Validation',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              FullNameTextField(
                focusNode: _fullnameNode,
                controller: _fullnameController,
                iconColor: Theme.of(context).primaryColor,
                autovalidateMode: AutovalidateMode.onUserInteraction,
                invalidNameMessage: 'Please enter a valid name',
                requiredNameMessage: 'Full name is required',
              ),
              const SizedBox(height: 16),

              const Text(
                'Phone Number',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              FlexiblePhoneField(
                controller: _phoneController,
                focusNode: _phoneNode,
                style: PhoneFieldStyle.dropdown,
                isShowError: true,
              ),
              const SizedBox(height: 15),

              const Text(
                'Fixed Country Code Style',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              FlexiblePhoneField(
                controller: TextEditingController(),
                focusNode: FocusNode(),
                style: PhoneFieldStyle.simple,
                isShowError: true,
              ),
              const SizedBox(height: 15),

              const Text(
                'Phone number with Icons',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              FlexiblePhoneField(
                controller: TextEditingController(),
                focusNode: FocusNode(),
                style: PhoneFieldStyle.withIcons,
                isShowError: true,
              ),
              const SizedBox(height: 15),

              const Text(
                'Phone number with Normal',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              FlexiblePhoneField(
                controller: TextEditingController(),
                focusNode: FocusNode(),
                style: PhoneFieldStyle.integrated,
                isShowError: true,
              ),
              const SizedBox(height: 15),

              const Text(
                'User Name TextField',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              UsernameTextfield(
                controller: _usernameController,
                focusNode: _usernameNode,
                autovalidateMode: AutovalidateMode.onUserInteraction,
                patternErrorMessage:
                    'Username must be 3-20 characters and can only contain letters, numbers, and underscore',
              ),
              const SizedBox(height: 24),

              const Text(
                'OTP Field',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              SizedBox(width: double.infinity, child: AdvancedOTPDemoScreen()),

              // AdvancedOTPField(
              //   length: 6,
              //   onCompleted: (value) {
              //     print('Completed: $value');
              //   },
              //   fieldStyle: const OTPFieldStyle(
              //     width: 45,
              //     height: 55,
              //     margin: EdgeInsets.symmetric(horizontal: 4),
              //     textStyle: TextStyle(
              //       fontSize: 20,
              //       fontWeight: FontWeight.bold,
              //     ),
              //   ),
              //   fieldDecoration: const OTPFieldDecoration(
              //     borderRadius: BorderRadius.all(Radius.circular(12)),
              //     borderWidth: 1.5,
              //   ),
              // ),
              const SizedBox(height: 24),

              ElevatedButton(
                onPressed: _submitForm,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: const Text('Submit'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
