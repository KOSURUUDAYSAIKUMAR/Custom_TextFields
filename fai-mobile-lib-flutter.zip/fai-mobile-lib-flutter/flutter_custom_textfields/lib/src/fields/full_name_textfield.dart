import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../custom_text_field.dart';
import '../validator/fullname_validator.dart';

class FullNameTextField extends StatelessWidget {
  final String? label;
  final String? hint;
  final TextEditingController? controller;
  final void Function(String)? onChanged;
  final String? Function(String?)? customValidator;
  final bool enabled;
  final FocusNode? focusNode;
  final Color? iconColor;
  final InputDecoration? inputDecoration;
  final Widget? trailingIcon;
  final String? customRegexPattern;
  final String? invalidNameMessage;
  final String? requiredNameMessage;
  final int? maxLength;
  final List<TextInputFormatter>? inputFormatters;
  final AutovalidateMode? autovalidateMode;

  const FullNameTextField({
    super.key,
    this.label = 'Full Name',
    this.hint = 'Enter your full name',
    this.controller,
    this.onChanged,
    this.customValidator,
    this.enabled = true,
    this.focusNode,
    this.iconColor,
    this.inputDecoration,
    this.trailingIcon,
    this.customRegexPattern,
    this.invalidNameMessage,
    this.requiredNameMessage,
    this.maxLength,
    this.inputFormatters,
    this.autovalidateMode = AutovalidateMode.onUserInteraction,
  });

  @override
  Widget build(BuildContext context) {
    if (customRegexPattern != null) {
      FullnameValidator.setCustomPattern(customRegexPattern!);
    }
    String? Function(String?) validator;
    if (customValidator != null) {
      validator = customValidator!;
    } else if (invalidNameMessage != null || requiredNameMessage != null) {
      validator =
          (value) => FullnameValidator.validateFullNameWithCustomMessage(
            value,
            errorMessage: invalidNameMessage ?? 'Please enter a valid name',
            requiredMessage: requiredNameMessage ?? 'Full name is required',
          );
    } else {
      validator = FullnameValidator.validateFullName;
    }
    return CustomTextField(
      label: label,
      hint: hint,
      controller: controller,
      keyboardType: TextInputType.name,
      leadingIcon: Icon(Icons.person_outline, color: iconColor ?? Colors.grey),
      trailingIcon: trailingIcon,
      validator: validator,
      onChanged: onChanged,
      enabled: enabled,
      focusNode: focusNode,
      inputDecoration: inputDecoration,
      textCapitalization: TextCapitalization.words,
      maxLength: maxLength,
      inputFormatters: inputFormatters,
      autovalidateMode: autovalidateMode,
    );
  }
}
