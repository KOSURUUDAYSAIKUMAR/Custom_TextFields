import 'package:flutter/material.dart';
import '../../custom_text_field.dart';
import '../validator/email_validator.dart';

class EmailTextField extends StatelessWidget {
  final String? label;
  final String? hint;
  final TextEditingController? controller;
  final void Function(String)? onChanged;
  final String? Function(String?)? customValidator;
  final bool enabled;
  final FocusNode? focusNode;
  final Color? iconColor;
  final InputDecoration? inputDecoration;
  final Widget? trailingIcon;
  final String? customRegexPattern;
  final String? invalidEmailMessage;
  final String? requiredEmailMessage;
  final AutovalidateMode? autovalidateMode;

  const EmailTextField({
    super.key,
    this.label = 'Email',
    this.hint = 'Enter your email',
    this.controller,
    this.onChanged,
    this.customValidator,
    this.enabled = true,
    this.focusNode,
    this.iconColor,
    this.inputDecoration,
    this.trailingIcon,
    this.customRegexPattern,
    this.invalidEmailMessage,
    this.requiredEmailMessage,
    this.autovalidateMode = AutovalidateMode.onUserInteraction,
  });

  @override
  Widget build(BuildContext context) {
    if (customRegexPattern != null) {
      EmailValidator.setCustomPattern(customRegexPattern!);
    }
    String? Function(String?) validator;
    if (customValidator != null) {
      validator = customValidator!;
    } else if (invalidEmailMessage != null || requiredEmailMessage != null) {
      validator =
          (value) => EmailValidator.validateEmailWithCustomMessage(
            value,
            errorMessage: invalidEmailMessage ?? 'Please enter a valid email',
            requiredMessage: requiredEmailMessage ?? 'Email is required',
          );
    } else {
      validator = EmailValidator.validateEmail;
    }
    return CustomTextField(
      label: label,
      hint: hint,
      controller: controller,
      keyboardType: TextInputType.emailAddress,
      leadingIcon: Icon(Icons.email_outlined, color: iconColor ?? Colors.grey),
      trailingIcon: trailingIcon,
      validator: validator,
      onChanged: onChanged,
      enabled: enabled,
      focusNode: focusNode,
      inputDecoration: inputDecoration,
      textCapitalization: TextCapitalization.none,
      autovalidateMode: autovalidateMode,
    );
  }
}
